package GameRoom;

/**
 * A base class to hold common attributes and behaviors.
 * This class is extended by Game, Team, and Player.
 */
public class Entity {
    private long id;
    private String name;

    /**
     * Default constructor is hidden to enforce providing id and name.
     */
    private Entity() {
    }

    /**
     * Constructor with id and name
     * @param id the unique identifier
     * @param name the name of the entity
     */
    public Entity(long id, String name) {
        this(); // Call to the hidden default constructor
        this.id = id;
        this.name = name;
    }

    /**
     * @return the unique identifier
     */
    public long getId() {
        return id;
    }

    /**
     * @return the name of the entity
     */
    public String getName() {
        return name;
    }

    /**
     * Returns a string representation of the entity.
     * @return a string with the id and name
     */
    @Override
    public String toString() {
        return "Entity [id=" + id + ", name=" + name + "]";
    }
}