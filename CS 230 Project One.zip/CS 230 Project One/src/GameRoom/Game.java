package GameRoom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a game
 * * <p>
 * Notice the use of the extends keyword to inherit from the Entity class.
 * </p>
 * * @author coce@snhu.edu
 *
 */
public class Game extends Entity {
    private List<Team> teams = new ArrayList<Team>();

    /**
     * Constructor for the game instance
     * * @param id   The unique identifier for the game
     * @param name The game's name
     */
    public Game(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a team to the game if a team with the same name doesn't already exist.
     * Uses an iterator pattern to check for existing team names.
     * * @param name The name of the team to add
     * @return The new team instance, or the existing one if the name is already
     * taken
     */
    public Team addTeam(String name) {
        Team team = null;

        // Create an iterator to look for a team with the same name
        Iterator<Team> teamsIterator = teams.iterator();

        // Loop through the list of teams
        while (teamsIterator.hasNext()) {
            Team teamInstance = teamsIterator.next();
            if (teamInstance.getName().equalsIgnoreCase(name)) {
                // Team found, return the existing instance
                team = teamInstance;
                return team;
            }
        }

        // If team is not found, create a new one and add it to the list
        if (team == null) {
            // Using a simple 1 for team ID as it's not managed by GameService in this scope
            team = new Team(1, name);
            teams.add(team);
        }

        return team;
    }

    @Override
    public String toString() {
        return "Game [id=" + super.getId() + ", name=" + super.getName() + "]";
    }
}
