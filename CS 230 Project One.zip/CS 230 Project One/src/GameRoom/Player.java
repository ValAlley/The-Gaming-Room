package GameRoom;

/**
 * A simple class to hold information about a player
 * <p>
 * Notice the use of the extends keyword to inherit from the Entity class.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Player extends Entity {

	/**
	 * Constructor for the player instance
	 * @param id The unique identifier for the player
	 * @param name The player's name
	 */
	public Player(long id, String name) {
		super(id, name);
	}

	@Override
	public String toString() {
		return "Player [id=" + super.getId() + ", name=" + super.getName() + "]";
	}
}
