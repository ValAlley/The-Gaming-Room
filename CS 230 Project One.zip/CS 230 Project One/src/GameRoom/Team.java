package GameRoom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the use of the extends keyword to inherit from the Entity class.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity {
	private List<Player> players = new ArrayList<Player>();
	
	/**
	 * Constructor for the team instance
	 * @param id The unique identifier for the team
	 * @param name The team's name
	 */
	public Team(long id, String name) {
		super(id, name);
	}

	/**
	 * Adds a player to the team if a player with the same name doesn't already exist.
	 * Uses an iterator to check for existing player names.
	 * * @param name The name of the player to add
	 * @return The new player instance, or the existing one if the name is already taken
	 */
	public Player addPlayer(String name) {
		Player player = null;
		
		// Create an iterator to look for a player with the same name
		Iterator<Player> playersIterator = players.iterator();
		
		// Loop through the list of players
		while(playersIterator.hasNext()) {
			Player playerInstance = playersIterator.next();
			if(playerInstance.getName().equalsIgnoreCase(name)) {
				// Player found, return the existing instance
				player = playerInstance;
				return player;
			}
		}
		
		// If player is not found, create a new one and add it to the list
		if (player == null) {
			// Using a simple 1 for player ID as it's not managed by GameService in this scope
			player = new Player(1, name); 
			players.add(player);
		}
		
		return player;
	}

	@Override
	public String toString() {
		return "Team [id=" + super.getId() + ", name=" + super.getName() + "]";
	}
}
