package GameRoom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton class to manage the games.
 * This ensures there is only one instance of GameService in memory.
 */
public class GameService {

    // A list of the active games
    private static List<Game> games = new ArrayList<Game>();

    // Next identifier values
    private static long nextGameId = 1;
    private static long nextPlayerId = 1;
    private static long nextTeamId = 1;

    // Private static instance of GameService
    private static GameService service;

    /**
     * Private constructor to prevent instantiation from outside the class.
     */
    private GameService() {
    }

    /**
     * Returns the singleton instance of the GameService.
     * If an instance does not exist, it creates one.
     * @return the singleton GameService instance
     */
    public static synchronized GameService getInstance() {
        if (service == null) {
            service = new GameService();
            System.out.println("New Game Service created.");
        } else {
            System.out.println("Game Service already exists.");
        }
        return service;
    }

    /**
     * Construct a new game instance
     * * @param name the unique name of the game
     * @return the game instance (new or existing)
     */
    public Game addGame(String name) {
        Game game = null;

        // Use an iterator to find a game with the same name.
        Iterator<Game> gamesIterator = games.iterator();
        
        while (gamesIterator.hasNext()) {
            Game gameInstance = gamesIterator.next();
            if (gameInstance.getName().equalsIgnoreCase(name)) {
                // Game with same name found, return existing instance
                return gameInstance;
            }
        }

        // If not found, make a new game instance and add to list of games
        if (game == null) {
            game = new Game(nextGameId++, name);
            games.add(game);
        }

        return game;
    }

    /**
     * Returns the game instance with the specified id.
     * * @param id unique identifier of game to search for
     * @return requested game instance, null if not found
     */
    public Game getGame(long id) {
        Game game = null;

        Iterator<Game> gamesIterator = games.iterator();
        while (gamesIterator.hasNext()) {
            Game gameInstance = gamesIterator.next();
            if (gameInstance.getId() == id) {
                game = gameInstance;
                break; // Found the game
            }
        }

        return game;
    }

    /**
     * Returns the game instance with the specified name.
     * * @param name unique name of game to search for
     * @return requested game instance, null if not found
     */
    public Game getGame(String name) {
        Game game = null;

        Iterator<Game> gamesIterator = games.iterator();
        while (gamesIterator.hasNext()) {
            Game gameInstance = gamesIterator.next();
            if (gameInstance.getName().equalsIgnoreCase(name)) {
                game = gameInstance;
                break; // Found the game
            }
        }

        return game;
    }

    /**
     * Returns the number of games currently active
     * * @return the number of games
     */
    public int getGameCount() {
        return games.size();
    }
    
    /**
	 * @return the next player id
	 */
	public long getNextPlayerId() {
		return nextPlayerId++;
	}

	/**
	 * @return the next team id
	 */
	public long getNextTeamId() {
		return nextTeamId++;
	}
}
