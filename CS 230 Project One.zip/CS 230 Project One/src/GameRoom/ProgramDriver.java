package GameRoom;

/**
 * Application Main-Class for testing the game classes.
 */
public class ProgramDriver {

    /**
     * The one and only main() method
     * * @param args command line arguments
     */
    public static void main(String[] args) {

        // Get the singleton instance of GameService
        GameService service = GameService.getInstance();

        System.out.println("\nAdded Games:");
        
        // Add a new game
        Game game1 = service.addGame("Game 1");
        System.out.println(game1);
        
        // Add another game
        Game game2 = service.addGame("Game 2");
        System.out.println(game2);
        
        // Try to add a game with a duplicate name
        Game game3 = service.addGame("Game 1");
        System.out.println(game3);

        System.out.println("\nRetrieving Games by ID:");
        System.out.println(service.getGame(1L));
        System.out.println(service.getGame(2L));

        System.out.println("\nRetrieving Games by Name:");
        System.out.println(service.getGame("Game 1"));
        System.out.println(service.getGame("Game 2"));

        // Add teams and players to Game 1
        Team team1 = game1.addTeam("Team A");
        Team team2 = game1.addTeam("Team B");

        team1.addPlayer("Player 1");
        team1.addPlayer("Player 2");
        
        team2.addPlayer("Player 3");
        team2.addPlayer("Player 4");
        
        System.out.println("\nGame 1 Details:");
        System.out.println(game1);
        // We would need to add methods to Game/Team to display children for a full test
        // For now, this demonstrates the object creation and relationships.
        
        // Test the Singleton pattern by trying to get the instance again
        System.out.println("\n-- Singleton Test --");
        GameService anotherService = GameService.getInstance();
        
        // The output should show that the service already exists
        // and both service and anotherService will refer to the same object.
        if (service == anotherService) {
            System.out.println("Both service variables point to the same instance. Singleton test passed.");
        } else {
            System.out.println("Singleton test failed.");
        }
        
        System.out.println("\nTotal games in service: " + service.getGameCount());
    }
}
